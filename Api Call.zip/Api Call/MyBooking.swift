//
//  MyBooking.swift
//  Pavone
//
//  Created by CTIMac on 12/04/19.
//  Copyright © 2019 CT. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

struct MyBooking
{
    var client_name: String?
    var salon_profile_image: String?
    var service_name:String?
    var book_dateTime: String?
    var salon_location: String?
    var salon_name:String?
    var service_cost:String?
    var barber_profile_image:String?
    var barber_name:String?
    var booking_status:String?
    var booking_id:String?
    
//    "salon_id" : "1",
//    "client_name" : "priyanka",
//    "salon_profile_image" : "https:\/\/ctinfotech.com\/CT01\/pavon\/assets\/salonfile\/profile\/e30a5a6cf0d088e95dada9607a26b74b.png",
//    "service_name" : "service1",
//    "book_dateTime" : "2019-02-04 11:30:00",
//    "salon_location" : "Vijay Nagar, Indore, Madhya Pradesh 452010, India",
//    "service_id" : "1",
//    "salon_name" : "Hubs",
//    "client_location" : "Indore, Madhya Pradesh, India",
//    "service_cost" : "20",
//    "client_id" : "1",
//    "notification_id" : "0",
//    "status" : "1",
//    "service_discrption" : "serjlljv inpibibe ibhhq ihbdipsn inxhid onions inindp ubirh sinidbieb ionfinppdxhcgja jvjva jvjks kbkbskv",
//    "barber_profile_image" : "https:\/\/ctinfotech.com\/CT01\/pavon\/assets\/salonfile\/barber\/d39be9557c612823286a962466f9f3d5.jpg",
//    "client_profile_image" : "https:\/\/ctinfotech.com\/CT01\/pavon\/assets\/clientfile\/profile\/",
//    "barber_name" : "Barber1",
//    "booking_id" : "1"
    
    init(_ dict: [String: JSON])
    {
        client_name = dict["client_name"]?.stringValue
        salon_profile_image = dict["salon_profile_image"]?.stringValue
        service_name = dict["service_name"]?.stringValue
        book_dateTime = dict["book_dateTime"]?.stringValue
        salon_location = dict["salon_location"]?.stringValue
        salon_name = dict["salon_name"]?.stringValue
        service_cost = dict["service_cost"]?.stringValue
        barber_profile_image = dict["barber_profile_image"]?.stringValue
        barber_name = dict["barber_name"]?.stringValue
        booking_status = dict["status"]?.stringValue
        booking_id = dict["booking_id"]?.stringValue
    }
    
    init(json: JSON)
    {
        client_name = json["client_name"].stringValue
        salon_profile_image = json["salon_profile_image"].stringValue
        service_name = json["service_name"].stringValue
        book_dateTime = json["book_dateTime"].stringValue
        salon_location = json["salon_location"].stringValue
        salon_name = json["salon_name"].stringValue
        service_cost = json["service_cost"].stringValue
        barber_profile_image = json["barber_profile_image"].stringValue
        barber_name = json["barber_name"].stringValue
        booking_status = json["status"].stringValue
        booking_id = json["booking_id"].stringValue
    }
}
