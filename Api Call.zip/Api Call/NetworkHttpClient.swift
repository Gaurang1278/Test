//
//  NetworkHttpClient.swift
//  Pavone
//
//  Created by ABC on 04/09/18.
//  Copyright © 2018 CreativeThoughtsInformatics. All rights reserved.


import UIKit
import Alamofire
import SwiftyJSON

class NetworkHttpClient: NSObject
{
    //MARK:Client
    
    static func callAPIWith(_ apiName: String, parameter: [String: Any] = [:], showHud: Bool = true, completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate

        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURL + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                for (key, value) in parameter {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                    case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithTerms(_ apiName: String, parameter: [String: Any] = [:], showHud: Bool = true, completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURLTerms + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                for (key, value) in parameter {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithImage(_ apiName: String, _ imageData : Data, parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURL + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                if (imageData.count > 0)
                {
                    multipartFormData.append(imageData, withName: "profile_image",fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {

                }
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                    case .success(let upload, _, _):
                    upload.responseJSON { response in
                       // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                    case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithSingleImage(_ apiName: String, _ imageData : Data, parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURL + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                if (imageData.count > 0)
                {
                    multipartFormData.append(imageData, withName: "country_image",fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWith2Image(_ apiName: String, _ imageData : Data , _ country_imageData :Data, parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURL + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                
                if (imageData.count > 0)
                {
                    multipartFormData.append(imageData, withName: "profile_image",fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                
                if (country_imageData.count > 0)
                {
                    multipartFormData.append(country_imageData, withName: "country_image",fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    //MARK:Salon
    
    static func callAPIWithSalonImage( apiName: String ,image_key : String,  imageData : Data, parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURLSalon + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                if (imageData.count > 0)
                {
                    multipartFormData.append(imageData, withName: image_key,fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                    case .success(let upload, _, _):
                    
                    upload.responseJSON { response in
                        // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithSalon(_ apiName: String, parameter: [String: Any] = [:], showHud: Bool = true, completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURLSalon + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                for (key, value) in parameter {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithMultiImagesSalon(_ apiName: String ,image_key : String,_ imageArray: [UIImage], parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURLSalon + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                
                for image in imageArray
                {
                    let imageData2: NSData? = UIImageJPEGRepresentation(image, 0.5) as NSData?
                    if imageData2 != nil
                    {
                        multipartFormData.append(imageData2! as Data , withName: image_key,fileName: "file.jpg", mimeType: "image/jpg")
                    }
                }
                
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
    static func callAPIWithSalonTwoImage( apiName: String ,image_key : String,  imageData : Data,image_key2 : String, _ imageData2 : Data, parameter: [String: Any] = [:], completionHandler: @escaping (Bool, JSON?, String?, Error?) -> Void)
    {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if (Connectivity.isConnectedToInternet() == true)
        {
            let headers: HTTPHeaders = ["Content-type": "multipart/form-data","Authorization": HeaderValue]
            
            let urlString = kBaseURLSalon + apiName
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key, value) in parameter
                {
                    multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
                }
                if (imageData.count > 0)
                {
                    multipartFormData.append(imageData, withName: image_key,fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                if (imageData2.count > 0)
                {
                    multipartFormData.append(imageData2, withName: image_key2,fileName: "file.jpg", mimeType: "image/jpg")
                }
                else
                {
                    
                }
                
            }, usingThreshold: UInt64.init(), to: urlString, method: .post, headers: headers) { (result) in
                
                switch result
                {
                case .success(let upload, _, _):
                    
                    upload.responseJSON { response in
                        // ShowLoder()
                        
                        do
                        {
                            DispatchQueue.main.async
                                {
                                    if let value = response.result.value
                                    {
                                        let responseJson = JSON(value)
                                        if responseJson["success"].string == "1"
                                        {
                                            completionHandler(true, responseJson, responseJson["message"].string, nil)
                                        }
                                        else if responseJson ["code"].string != "1"
                                        {
                                            completionHandler(false, responseJson, responseJson["message"].string, nil)
                                        }
                                    }
                                    else
                                    {
                                        completionHandler(false, nil, couldNotConnect, response.result.error)
                                    }
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error in upload: \(error.localizedDescription)")
                    completionHandler(false, nil, error.localizedDescription, error)
                }
            }
        }
        else
        {
            appDelegate.showAlert(title: Appttitle,message:NetworkCheck,buttonTitle: alertok);
        }
    }
    
}

