//
//  ApiService.swift
//  Pavone
//
//  Created by ABC on 4/17/18.
//  Copyright © 2018 ABC. All rights reserved.
//


import Foundation
import UIKit.UIImage

// API paths.
public enum RequestPath: String
{
    case LoginApi  = "login"
    case SignupApi = "signup"
    case ForgotPasswordApi = "forgot_passowrd"
    case LogoutApi = "logout"
    case SalonlistApi = "salon_list"
    case NotilistApi = "notification_list"
    case SalonNoticountApi = "salon/show_count"
    case Showclient_detail = "client_detail"
    case ShowNewBooking = "newBooking"
    case AddBooking = "addBook"
    case DeleteBooking = "delete_booking"
    case ShowAboutSalon = "salon_detail"
    case SocialloginApi = "social_login"
    case Verification = "otp_verification"
    case Update_badgecount = "update_badge_count"
    case Salonupdate_badgecount = "salon/update_badge_count"
    case MyBooking_list = "my_booking"
    case Change_password = "change_password"
    case UpdateProfile = "updateProfile"
    case Service_list = "service_list"
    case Offer_lsit = "offer_list"
    case SalonRatingList = "salonRatingList"
    case AddRating = "addRating"
    case searchItems = "searchItems"
    case CatagoryList = "salon/category_list"
    case SalonSignupApi = "salon/signup"
    case SalonLoginApi  = "salon/login"
    case SalonLogout = "salon/logout"
    case SalonChangePass = "salon/change_password"
    case salonMyBooking = "salon/my_booking"
    case BarberList = "salon/barber_list"
    case UpdateBArber = "salon/updateBarber"
    case SalonShow_detail = "salon/salon_detail"
    case ShowSalonBackgroundImage = "salon/showSalonBackgroundImage"
    case addSalonBackgroundImage = "salon/addSalonBackgroundImage"
    case deleteBackgroundImage = "salon/deleteBackgroundImage"
    case Booking_Accept_reject = "salon/accept_reject_booking"
    case AddBarber = "salon/addBarber"
    case SalonOTP_verify = "salon/otp_verify"
    case SalonUpdateProfile = "salon/updateProfile"
    case AddService = "salon/addServices"
    case DeleteORUpdateSerive = "salon/editServices"
    case deleteSerivceImage = "salon/delete_service_image"
    case ServiceList = "salon/service_list"
    case SalonSocialloginApi = "salon/social_login"
    case SalonNotificationList = "salon/notification_list"
    case SalonSubscriptionList = "salon/subscription_plan_list"
    case SalonAdvertismentList = "salon/advertisement_plan_list"
    case Salonadd_advertisement = "salon/add_advertisement"
    case deleteService = "salon/delete_service"
    case deleteBarber = "salon/delete_barber"
    case Generate_checkout_key = "salon/key_generate_request"
    case GetPaymentStatus = "salon/check_payment_status"
    case SalonForgotPasswordApi = "salon/forgot_passowrd"
    case TermsandCondition = "api/get_terms_condition"
    case PrivacyPolicy = "api/get_privacy_policy"
    case Faq = "api/get_faq"
}

