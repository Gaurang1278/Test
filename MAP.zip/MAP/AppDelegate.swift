//
//  AppDelegate.swift
//  Pavone
//
//  Created by CT on 3/14/19.
//  Copyright © 2019 CT. All rights reserved.
//

import UIKit
import UserNotifications
import IQKeyboardManagerSwift
import UserNotifications
import FBSDKLoginKit
import TwitterKit
import CoreLocation
import GoogleMaps
import GooglePlaces
import Fabric
import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate , CLLocationManagerDelegate
{
    var window: UIWindow?
    var device_token:String = String()
    var greeting = ""
    let mapKey = "AIzaSyCXh13h3eqG9mAt18erwqyb3luiac_0XV0"
    var latitude : Float = Float()
    var longitude : Float = Float()
    var locationManager = CLLocationManager()
    var currentLocation: CLLocation!
    var locality:String = String()
    var address:String = String()
    var country:String = String()
    var coordinate_current:CLLocationCoordinate2D = CLLocationCoordinate2D()

    struct TwitterCredentials
    {
        static let consumerKey = "BQ13O459sEbOwD4IGmIeAC3u8"
        static let consumerSecret = "SbCkvMA81vuqONmITpOR6DFFma6PoEEBP7kmWqdsnIcNKpvr2Q"
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
        //IQKeyboardManager Enable//
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        
        LocationPermission()
        
        // You MUST do this HERE and nowhere else!
        UNUserNotificationCenter.current().delegate = self
        
        // iOS 10 support
        if #available(iOS 10, *)
        {
            UNUserNotificationCenter.current().requestAuthorization(options:[.badge, .alert, .sound]){ (granted, error) in }
            application.registerForRemoteNotifications()
        }
            // iOS 9 support
        else if #available(iOS 9, *)
        {
        UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
            // iOS 8 support
        else if #available(iOS 8, *)
        {
        UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
        // iOS 7 support
        else
        {
            application.registerForRemoteNotifications(matching: [.badge, .sound, .alert])
        }
        
        GMSServices.provideAPIKey(mapKey)
        GMSPlacesClient.provideAPIKey(mapKey)
        
        TWTRTwitter.sharedInstance().start(withConsumerKey: TwitterCredentials.consumerKey, consumerSecret: TwitterCredentials.consumerSecret)
        
        Fabric.with([Crashlytics.self])
        
        return true
    }
    
    //MARK:Location Permission
    func LocationPermission()
    {
        if (CLLocationManager.locationServicesEnabled())
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
            //locationManager.allowsBackgroundLocationUpdates = true
        }
    }
    
    // MARK :- Current Location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
        self.latitude = Float(locValue.latitude)
        self.longitude = Float(locValue.longitude)
        
        CLGeocoder().reverseGeocodeLocation(locationManager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks?[0]
                self.displayLocationInfo(pm)
            } else {
                print("Problem with the data received from geocoder")
            }
        })
    }
    
    func displayLocationInfo(_ placemark: CLPlacemark?)
    {
        if let containsPlacemark = placemark
        {
            country = (containsPlacemark.country != nil) ? containsPlacemark.country! : ""
            
            //indore:-22.7196 75.8577
            //Bahrain:-26.0667 50.5577
            //Gaja:-31.51872 34.4479604
            
            locality = NSString(format:"%@,%@", containsPlacemark.administrativeArea!, containsPlacemark.country!) as String
            
//            if (containsPlacemark.thoroughfare == nil)
//            {
//
//            }
//            else
//            {
//                locality = NSString(format:"%@", containsPlacemark.thoroughfare!) as String
//            }
            
            var addressString : String = ""
            if containsPlacemark.subLocality != nil {
                addressString = addressString + containsPlacemark.subLocality! + ", "
            }
            if containsPlacemark.thoroughfare != nil {
                addressString = addressString + containsPlacemark.thoroughfare! + ", "
            }
            if containsPlacemark.locality != nil {
                addressString = addressString + containsPlacemark.locality! + ", "
            }
            if containsPlacemark.country != nil {
                addressString = addressString + containsPlacemark.country! + ", "
            }
            if containsPlacemark.postalCode != nil {
                addressString = addressString + containsPlacemark.postalCode! + " "
            }
            
            address = addressString
            print(address)
            
            //stop updating location to save battery life
            locationManager.stopUpdatingLocation()
        }
    }
    
    //MARK:- Device Token
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data)
    {
        // Convert token to string
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print("APNs device token: \(deviceTokenString)")
        device_token = deviceTokenString
    }
    
    // Called when APNs failed to register the device for push notifications
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error)
    {
        // Print the error to console (you should alert the user that registration failed)
        print("APNs registration failed: \(error)")
    }
    
    // Push notification received
    func application(_ application: UIApplication, didReceiveRemoteNotification data: [AnyHashable : Any])
    {
        // Print notification payload data
        print("Push notification received: \(data)")
    }
    
    //Push Notification Background
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void)
    {
        self.application(application: application, didReceiveRemoteNotification: userInfo as [NSObject : AnyObject])
    }
    
    private func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject])
    {
        // Print notification payload data
        print("Push notification received: \(userInfo)")
        print("Recived: \(userInfo)")
        //let temp : NSDictionary = userInfo as NSDictionary
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool
    {
        // Override point for customization after application launch.
        
        if url.scheme?.localizedCaseInsensitiveCompare(Config.urlScheme) == .orderedSame
        {
            // Send notification to handle result in the view controller.
            NotificationCenter.default.post(name: Notification.Name(rawValue: Config.asyncPaymentCompletedNotificationKey), object: nil)
            return true
        }
        
        let returnValuen = UserDefaults.standard.string(forKey: "LoginStatus")
        
        if(returnValuen == "FB")
        {
            return FBSDKApplicationDelegate.sharedInstance().application(app, open: url, options: options)
        }
        else if(returnValuen == "Twitter")
        {
            // Fabric.with([Twitter.self])
            //return Twitter.sharedInstance().application(app, open: url, options: options)
            return TWTRTwitter.sharedInstance().application(app, open: url, options: options)
        }
        
        return true
    }
    
    func application(_ application: UIApplication, shouldAllowExtensionPointIdentifier extensionPointIdentifier: UIApplicationExtensionPointIdentifier) -> Bool {
        if (extensionPointIdentifier == UIApplicationExtensionPointIdentifier.keyboard) {
            return false
        }
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        
        application.applicationIconBadgeNumber = 0;
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        
        application.applicationIconBadgeNumber = 0;
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    //MARK:- Show Alert
    func showAlert(title : String,message : String,buttonTitle : String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: buttonTitle, style: UIAlertAction.Style.default, handler: nil))
        window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    //MARK:- Check Valid Email
    func isValidEmail(testStr:String) -> Bool
    {
        let regex1 = "\\A[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\\.)+[a-z]{2,4}\\z"
        let regex2 = "^(?=.{1,64}@.{4,64}$)(?=.{6,100}$).*"
        let test1 = NSPredicate(format: "SELF MATCHES %@", regex1)
        let test2 = NSPredicate(format: "SELF MATCHES %@", regex2)
        return test1.evaluate(with: testStr) && test2.evaluate(with: testStr)
    }
}

extension AppDelegate: UNUserNotificationCenterDelegate
{
    // These delegate methods MUST live in App Delegate and nowhere else!
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void)
    {
        if notification.request.content.userInfo is [String : AnyObject]
        {
            
        }
        completionHandler([.alert, .badge, .sound])
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void)
    {
        if response.notification.request.content.userInfo is [String : AnyObject]
        {
            
        }
        completionHandler()
    }
}

/*
 Pavone strings
 
 1.Could not able to connect with server.Please try again.
 2.Server Error
 
 3.Please enter email
 
 4.Please enter valid email
 
 5.Please enter password
 
 6.Please enter password with minimum 6 characters
 
 7.Please enter old password
 
 8.Please enter new password
 
 9.Please enter confirm password
 
 10.New password and confirm password does not match
 
 11.Please enter name
 
 12.Please agree terms and condition
 
 13.Please enter mobile number
 
 14.Please enter verification code
 
 15.Please enter correct verification code
 
 16.Please send verification code
 
 17.Otp does not matched
 
 18.OK
 
 19.Cancel
 
 20.Choose Image
 
 21.Camera
 
 22.Please select booking time
 
 23.Gallery
 
 24.Please search by name
 
 25.Please enter salon name
 
 26.Please select category
 
 27.Please enter salon specifications
 
 28.Please select profile image
 
 29.Please enter salon working hours
 
 30.Please select salon time schedule
 
 31.Please enter bio
 
 32.Please enter barber name
 
 33.Please enter location
 
 34.Please select country code
 
 35.Please enter service name
 
 36.Please enter service cost
 
 37.Please enter description
 
 38.Please enter any offer
 
 39.Please enter any offer price
 
 40.Please enter any offer description
 
 41.Please select country image
 
 42.Please select day
 
 43.Please select start time
 
 44.already member? LOGIN
 
 45.Home
 
 46.Notification
 
 47.Profile
 
 48.Settings
 
 49.Logout
 
 50.Are you sure?
 
 51.Are you sure you want to Log out?
 
 52.Log Out Now
 
 53.No Cancel
 
 54.BEST SALONS APP
 
 55.Set your location to start exploring salons around you
 
 56. SKIP
 
 57.Who Are You?
 
 58. Client
 
 59. Salon
 
 60. Female
 
 61.Male
 
 62.SIGN UP
 
 63.SIGN UP WITH
 
 66.OR
 
 67. Email
 
 68.PRIVACY POLICY
 
 69. Salons
 
 70.Open
 
 71.Search
 
 72.Select Photo
 
 73.Name
 
 74.E-Mail
 
 75.Password
 
 76.Enter name
 
 77.Enter email
 
 78.Enter password
 
 79.Terms & Privacy Policy
 
 80.SIGN IN
 
 81.Forgot Password?
 
 82.Forgot password
 
 83.Send verification code
 
 84.Mobile Number
 
 85.Mobile No.
 
 86.SEND CODE
 
 87.Enter Mobile No.
 
 88.Code
 
 89. Submit
 
 90.SALON INFO
 
 91.Salon name
 
 92.Enter salon name
 
 93. Category
 
 94.Salon Specification
 
 95.Select Category
 
 96.ADD
 
 97.Terms of services
 
 98.Terms of Service
 
 99. Accept
 
 100.Decline
 
 101.SUPPORTS & FAQS
 
 102.Payments and Discount Fees
 
 103.Booking information
 
 104.Best Offers
 
 105.Direction
 
 106. Bookings
 
 107.All of My Last reserve
 
 108.Nothing to See Here!
 
 109.How about we start by
 
 110.Book Now
 
 111.Do you really want to delete this booking?
 
 112.Accepted
 
 113.Rejected
 
 114.Home
 
 115.Find the perfect salon
 
 116.Filter
 
 117.Men Salons
 
 118. Rating
 
 119.Start From
 
 120. Distance
 
 121.Featured Salons
 
 122.See All
 
 123.Only opened salon
 
 124.Length
 
 125.Discover
 
 126.Search Name or Barber
 
 127.Orders
 
 128.Rates
 
 129.Type
 
 130.Gender
 
 131. Location
 
 132.Notifications
 
 133.Contact Us
 
 134.You can also contact us via whatApp!
 
 135.Message Title
 
 136.Message
 
 137.Send a notification
 
 138.Barbers
 
 139.BIO
 
 140.Address
 
 141.Get Direction
 
 142.Opening Hours
 
 143.Services
 
 144.Change Password
 
 145.Old password
 
 146.New password
 
 147.Confirm password
 
 148.Update
 
 149.Edit Profile
 
 150.Done
 
 151.Send OTP
 
 152.About Pavone
 
 153.Pavone Mobile App
 
 154.There are only two ways to live your life. One is as though nothing is miracel
 
 155.Phones
 
 156.Select Service
 
 157.Select Barber
 
 158.Date & Time
 
 159.Account
 
 160.Subscribe
 
 161.Quick Access
 
 162.Booking
 
 163.Full message
 
 164.Specifications
 
 165.Image
 
 166.Time Schedule
 
 167.DONE
 
 168.Are you sure you want to deactive the Barber?
 
 169.+ Add New
 
 170.Show for Clients
 
 171.Service Allow For Home Booking
 
 172.CONFIRM
 
 173.Confirm the barber
 
 174.Please confirm the barber before send it to the management
 
 175.No Thanks!
 
 176. New Barber
 
 177. DELETE
 
 178.EDIT
 
 179.New Service
 
 180.Start date
 
 181.Expire date
 
 182.Images
 
 183.Upload Images
 
 184.Services Allow For Home Booking
 
 185.Make An Offer On Service
 
 186. Reject
 
 */

