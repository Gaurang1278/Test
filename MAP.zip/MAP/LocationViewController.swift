//
//  LocationViewController.swift
//  Pavone
//
//  Created by CT on 3/29/19.
//  Copyright © 2019 CT. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps
import GooglePlaces
import MapKit

class LocationViewController: UIViewController, CLLocationManagerDelegate,UITextFieldDelegate,GMSMapViewDelegate
{
    //Current Latitude
    var latitude :Float = Float()
    var longitude :Float = Float()
    var addres:String = String()
    var country:String = String()
    
    //Pickup Latitude
    var pickuplatitue: String = String()
    var pickuplongitude: String = String()
    var pickupaddress: String = String()
    var marker = GMSMarker()
    var locationManager: CLLocationManager = CLLocationManager()
    var appDelegate = AppDelegate()
    
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var tfSearch: UITextField!
    @IBOutlet weak var img_top: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Google Map
        appDelegate = UIApplication.shared.delegate as! AppDelegate

        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        mapView.delegate = self
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.TappedInImage(_:)))
        img_top.addGestureRecognizer(tap)
        img_top.isUserInteractionEnabled = true
    }
    
    @objc func TappedInImage(_ sender: UITapGestureRecognizer)
    {
        //alertOpenCamraOrGalary()
        self.navigationController?.popViewController(animated: true)
        //type = "1"
    }
    
    //MARK:- IBACtion
    @IBAction func doclickonNext(_ sender: Any)
    {
        //UserSignupViewController
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "UserSignupViewController") as! UserSignupViewController
        signup.lattitude = self.pickuplatitue
        signup.longitude = self.pickuplongitude
        signup.address = self.pickupaddress
        self.navigationController?.pushViewController(signup, animated: true)
    }

    //MARK:- Location Update
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let newLocation = locations.last
        mapView.camera = GMSCameraPosition.camera(withTarget: newLocation!.coordinate, zoom: 6.0)
        
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
        self.latitude = Float(locValue.latitude)
        self.longitude = Float(locValue.longitude)
        
        CLGeocoder().reverseGeocodeLocation(locationManager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil)
            {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0
            {
                let pm = placemarks?[0]
                self.displayLocationInfo(pm)
            }
            else
            {
                print("Problem with the data received from geocoder")
            }
        })
    }
    
    func displayLocationInfo(_ placemark: CLPlacemark?)
    {
        if let containsPlacemark = placemark
        {
            //stop updating location to save battery life
            
            //addres = appDelegate.address
            country = (containsPlacemark.country != nil) ? containsPlacemark.country! : ""
            
            addres = NSString(format:"%@,%@", containsPlacemark.administrativeArea!, containsPlacemark.country!) as String
            
//            if (containsPlacemark.thoroughfare == nil)
//            {
//
//            }
//            else
//            {
//                addres = NSString(format:"%@", containsPlacemark.thoroughfare!) as String
//            }
            

            self.pickuplatitue = String(appDelegate.latitude)
            self.pickuplongitude = String(appDelegate.longitude)
            self.pickupaddress = addres
            tfSearch.text = addres
            
            let camera = GMSCameraPosition.camera(withLatitude: CLLocationDegrees(appDelegate.latitude), longitude: CLLocationDegrees(appDelegate.longitude), zoom: 16.0)
            mapView.camera = camera
            mapView.settings.zoomGestures = true
            mapView.animate(to: camera)
            mapView.isMyLocationEnabled = true
            
            //showMarkerLocation(position: camera.target)
            locationManager.stopUpdatingLocation()
            // RouteDraw()
        }
        
        //viewMap.padding = UIEdgeInsets(top: 0, left: 0, bottom: 500, right: 10)
    }
    
    func showMarkerLocation(position: CLLocationCoordinate2D)
    {
        let marker3 = GMSMarker()
        marker3.position = position
        marker3.title = self.tfSearch.text
        marker3.icon = UIImage(named: "blue_pin")!.withRenderingMode(.alwaysTemplate)
        marker3.map = mapView
    }
    
    //MARK: - Open Place Picker
    func openGooglePlacePicker()
    {
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.delegate = self
        present(autocompleteController, animated: true, completion: nil)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        self.view.endEditing(true)
        
        if textField == tfSearch
        {
            openGooglePlacePicker()
        }
    }
    
    //MARK:Map Tap
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D)
    {
        self.mapView.clear()
        self.pickuplatitue = String(coordinate.latitude)
        self.pickuplongitude = String(coordinate.longitude)
        
        let cityCoords = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        getAdressName(coords: cityCoords)
    }
    
    func getAdressName(coords: CLLocation)
    {
        CLGeocoder().reverseGeocodeLocation(coords) { (placemark, error) in
            if error != nil
            {
                print("Hay un error")
            }
            else
            {
                if (placemark?.count)! > 0
                {
                    let pm = placemark?[0]
                    self.ShowLocationInfo(pm)
                }
                else
                {
                    print("Problem with the data received from geocoder")
                }
            }
        }
    }
    
    func ShowLocationInfo(_ placemark: CLPlacemark?)
    {
        if let containsPlacemark = placemark
        {
            addres = NSString(format:"%@,%@", containsPlacemark.administrativeArea!, containsPlacemark.country!) as String
            
//            if (containsPlacemark.thoroughfare == nil)
//            {
//
//            }
//            else
//            {
//                addres = NSString(format:"%@", containsPlacemark.thoroughfare!) as String
//            }

            self.pickupaddress = addres
            tfSearch.text = addres
            
            let camera = GMSCameraPosition.camera(withLatitude: (CLLocationDegrees(self.pickuplatitue))!, longitude: (CLLocationDegrees(self.pickuplongitude))!, zoom: 16.0)
            mapView.camera = camera
            mapView.settings.zoomGestures = true
            mapView.animate(to: camera)
            mapView.isMyLocationEnabled = true
            showMarkerLocation(position: camera.target)
        }
    }
}

//MARK:Place Picker Delegates
extension LocationViewController : GMSAutocompleteViewControllerDelegate
{
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace)
    {
        mapView.clear()
        
        tfSearch.text = place.formattedAddress
        self.pickuplatitue = String(place.coordinate.latitude)
        self.pickuplongitude = String(place.coordinate.longitude)
        self.pickupaddress = place.formattedAddress!
        
        let camera = GMSCameraPosition.camera(withLatitude: (CLLocationDegrees(self.pickuplatitue))!, longitude: (CLLocationDegrees(self.pickuplongitude))!, zoom: 16.0)
        self.mapView.camera = camera
        self.mapView.settings.zoomGestures = true
        self.mapView.animate(to: camera)
        showMarkerLocation(position: camera.target)
        
        // selectedCoordinates = place.coordinate
        dismiss(animated: true, completion: nil)
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error)
    {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    func wasCancelled(_ viewController: GMSAutocompleteViewController)
    {
        dismiss(animated: true, completion: nil)
    }
    
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController)
    {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController)
    {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}

