//
//  ProfileDetailModel.swift
//  Pavone
//
//  Created by CT on 4/17/19.
//  Copyright © 2019 CT. All rights reserved.
//

import Foundation
import UIKit

struct ProfileModel
{
    var userName: String!
    var specification: String?
    var salon_id: String?
    var bio:String?
    var country_image:String?
    
    var login_type: String?
    var location: String?
    var latitude: String?
    
    var status: String?
    var profile_image: String?
    var social_type: String?
    
    var longitude: String?
    var salon_name: String?
    var email: String?
    
    var order_count: String?
    var avg_rating: String?
    var gender: String?
    
    var phone_number: String?
    var pendingCount: Int?
    var category: [JSON]
    var time_schedule: [JSON]
    var country_code : String?
    var barber_count:String?
    var rating_count:String?
    var full_name : String?
    var subscription_count: String?

    init(_ dict: [String: JSON])
    {
        // pendingCount = dict["not_confiremed_count"]?.intValue
        
        userName = dict["name"]!.stringValue
        salon_id = dict["salon_id"]?.stringValue
        barber_count = dict["barber_count"]?.stringValue
        rating_count = dict["rating_count"]?.stringValue
        bio = dict["bio"]?.stringValue
        country_image = dict["country_image"]?.stringValue
        subscription_count = dict["subscription_count"]?.stringValue
        
        login_type = dict["login_type"]?.stringValue
        location = dict["location"]?.stringValue
        latitude = dict["latitude"]?.stringValue
        
        userName = dict["name"]?.stringValue
        salon_id = dict["salon_id"]?.stringValue
        specification = dict["specification"]?.stringValue
        
        login_type = dict["login_type"]?.stringValue
        location = dict["location"]?.stringValue
        latitude = dict["latitude"]?.stringValue
        
        status = dict["status"]?.stringValue
        profile_image = dict["profile_image"]?.stringValue
        social_type = dict["social_type"]?.stringValue
        
        longitude = dict["longitude"]?.stringValue
        email = dict["email"]?.stringValue
        salon_name = dict["salon_name"]?.stringValue
        
        order_count = dict["order_count"]?.stringValue
        avg_rating = dict["avg_rating"]?.stringValue
        phone_number = dict["phone_number"]?.stringValue
        country_code = dict["country_code"]?.stringValue
        full_name = dict["full_name"]?.stringValue
        category = []
        
        if let arr = dict["category"]?.array {
            for obj in arr {
                category.append(obj)
            }
        }
        
        time_schedule = []
        if let arr = dict["time_schedule"]?.array {
            for obj in arr {
                time_schedule.append(obj)
            }
        }
    }
    
    init(json: JSON)
    {
        
        userName = json["name"].string
        salon_id = json["salon_id"].stringValue
        specification = json["specification"].stringValue
        barber_count = json["barber_count"].stringValue
        rating_count = json["rating_count"].stringValue
        bio = json["bio"].stringValue
        country_image = json["country_image"].stringValue
        subscription_count = json["subscription_count"].stringValue

        login_type = json["login_type"].stringValue
        location = json["location"].stringValue
        latitude = json["latitude"].stringValue
        
        userName = json["name"].stringValue
        salon_id = json["salon_id"].stringValue
        
        login_type = json["login_type"].stringValue
        location = json["location"].stringValue
        latitude = json["latitude"].stringValue
        
        status = json["status"].stringValue
        profile_image = json["profile_image"].stringValue
        social_type = json["social_type"].stringValue
        
        longitude = json["longitude"].stringValue
        email = json["email"].stringValue
        salon_name = json["salon_name"].stringValue
        
        order_count = json["order_count"].stringValue
        avg_rating = json["avg_rating"].stringValue
        phone_number = json["phone_number"].stringValue
        country_code = json["country_code"].stringValue
        full_name = json["full_name"].stringValue
        
        //pendingCount = json["not_confiremed_count"].intValue
        
        category = []
        if let arr = json["category"].array {
            for obj in arr {
                category.append(obj)
            }
        }
        
        time_schedule = []
        if let arr = json["time_schedule"].array {
            for obj in arr {
                time_schedule.append(obj)
            }
        }
        
    }
}



struct ProfileCategoryModel {
    
    var name: String?
    var category_id: String?
    
    init(_ dict: [String: JSON])
    {
        
        name = dict["name"]?.stringValue
        category_id = dict["category_id"]?.stringValue
    }
    
    init(json: JSON)
    {
        
        name = json["name"].stringValue
        category_id = json["category_id"].stringValue
    }
    
}

struct ProfileTimescheduleModel
{
    var day: String?
    var end_time: String?
    var salon_id: String?
    var time_schedule_id: String?
    var start_time: String?
    
    init(_ dict: [String: JSON])
    {
        day = dict["day"]?.stringValue
        end_time = dict["end_time"]?.stringValue
        salon_id = dict["salon_id"]?.stringValue
        time_schedule_id = dict["time_schedule_id"]?.stringValue
        start_time = dict["start_time"]?.stringValue
    }
    
    init(json: JSON)
    {
        day = json["day"].stringValue
        end_time = json["end_time"].stringValue
        salon_id = json["salon_id"].stringValue
        time_schedule_id = json["time_schedule_id"].stringValue
        start_time = json["start_time"].stringValue
    }
}

struct SalonBackgountImagesModel
{
    var salon_image_id: String?
    var salon_image: String?
    var salon_id: String?
    var default_status : String?
    
    init(_ dict: [String: JSON])
    {
        salon_image_id = dict["salon_image_id"]?.stringValue
        salon_image = dict["salon_image"]?.stringValue
        salon_id = dict["salon_id"]?.stringValue
        default_status = dict["default_status"]?.stringValue
    }
    
    init(json: JSON)
    {
        salon_image_id = json["salon_image_id"].stringValue
        salon_image = json["salon_image"].stringValue
        salon_id = json["salon_id"].stringValue
        default_status = json["default_status"].stringValue
    }
}



