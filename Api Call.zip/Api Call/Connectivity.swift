//
//  Connectivity.swift
//  ReachablityAlomfire
//
//  Created by CTIMac on 28/02/19.
//  Copyright © 2019 CTIMac. All rights reserved.
//

import Foundation
import Alamofire

class Connectivity
{
    class func isConnectedToInternet() ->Bool
    {
        return NetworkReachabilityManager()!.isReachable
    }
}
