//
//  Constant.swift
//  Pavone
//
//  Created by CT on 8/31/18.
//  Copyright © 2018 CT. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON

//let kBaseURL = "https://ctinfotech.com/CT01/basmah/api/"
let kBaseURL = "https://ctinfotech.com/CT01/pavon/client/"
let kBaseURLSalon = "https://ctinfotech.com/CT01/pavon/"
let kBaseURLTerms = "https://ctinfotech.com/CT01/pavon/"
let themecolor = UIColor.init(red: 0/255.0, green: 173/255.0, blue: 239/255.0, alpha: 1.0)
let SubsColor = UIColor.init(red:7/255.0, green: 130/255.0, blue: 191/255.0, alpha: 1.0)
let Appttitle = "Pavone"
let loginDetail = "UserDefaultLoginDetail"
let NetworkCheck = "Could not able to connect with server.Please try again."
let alertservererr = "Server Error"
let alertemail = "Please enter email"
let alertvalidemail = "Please enter valid email"
let alertpwdlimit = "Please enter password with minimum 6 characters"
let alertpwd = "Please enter password"
let alertolpwd = "Please enter old password"
let alertnwpwd = "Please enter new password"
let alertcnfpwd = "Please enter confirm password"
let alertpwdmatch = "New password and confirm password does not match"
let alertname = "Please enter name"
let alertTerms = "Please agree terms and condition"
let alertmobile = "Please enter mobile number"
let alertverifi = "Please enter verification code"
let alertCorrectVerfi = "Please enter correct verification code"
let alertsendverifi = "Please send verification code"
let alertInstall = "Please install google maps"
let alertVerify = "Otp does not matched"
let alertok = "OK"
let alertcancel = "Cancel"
let alertchooseimage = "Choose Image"
let alertcamera = "Camera"
let alerttime = "Please select booking time"
let alertService = "Please select service"
let alertgallery = "Gallery"
let alertnocamera = "You don't have camera"
let HeaderValue = "dfs#!df154$"
let alertSearch = "Please search by name"
let alertsalonName = "Please enter salon name"
let alertsalonCat = "Please select category"
let alertsalonsapecification = "Please enter salon specifications"
let alertselectImage = "Please select profile image"
let alertselectBarberImage = "Please select barber image"
let alertselectSerImage = "Please select service image"
let alertsalonworkinghours = "Please enter salon working hours"
let alertsalonworkingday = "Please select salon time schedule"
let alertBio = "Please enter bio"
let alertBarberName = "Please enter barber name"
let alertLocation = "Please enter location"
let alertCountryCode = "Please select country code"
let alertServiceName = "Please enter service name"
let alertServicecost = "Please enter service cost"
let alertStartTime = "Please select start Date"
let alertOfferStartTime = "Please select offer start date"
let alertOfferEndTime = "Please select offer end date"
let alertOfferCost = "Please enter offer cost"
let alertEndTime = "Please select end Date"
let alertDescription = "Please enter description"
let alertanyOfer = "Please enter any offer"
let alertanyOferPrice = "Please enter any offer price"
let alertanyOferDesc = "Please enter any offer description"
let alertCountryCodeImg = "Please select country image"
let alertSelectDay = "Please select day"
let alertSelectSartTime = "Please select start time"
let alertBookingType = "Please select booking type"
let alertSelectOfferImage = "Please select offer image"

var appDelegate = AppDelegate()
let couldNotConnect = "Could not able to connect with server. Please try again."

func MoveTab(Button:UIButton)
{
    UIView.animate(withDuration: 0.4,
                   animations:
        {
            Button.transform = CGAffineTransform(scaleX: -0.3, y: -0.3)
        },
            completion: { _ in
            UIView.animate(withDuration: 0.4)
            {
                Button.transform = CGAffineTransform.identity
            }
    })
}
