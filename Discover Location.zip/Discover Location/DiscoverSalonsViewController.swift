//
//  DiscoverSalonsViewController.swift
//  Pavone
//
//  Created by CT on 4/1/19.
//  Copyright © 2019 CT. All rights reserved.
//

import UIKit
import CoreLocation
//import CoreLocation
import MaterialActivityIndicator
import MapKit

class POIItem: NSObject, GMUClusterItem
{
    var position: CLLocationCoordinate2D
    var location: String!
    var salon_id : String!
    var salon_name : String!
    
    init(position: CLLocationCoordinate2D, location: String , salon_id : String , salon_name: String )
    {
        self.position = position
        self.location = location
        self.salon_id = salon_id
        self.salon_name = salon_name
    }
}

class DiscoverSalonsViewController: UIViewController, CLLocationManagerDelegate,GMSMapViewDelegate ,GMUClusterManagerDelegate, GMUClusterRendererDelegate
{
    //Current Latitude
    var latitude :Float = Float()
    var longitude :Float = Float()
    var addres:String = String()
    var country:String = String()
    
    //Pickup Latitude
    var pickuplatitue: Float = Float()
    var pickuplongitude: Float = Float()
    var pickupaddress: String = String()
    var marker = GMSMarker()
    var locationManager: CLLocationManager = CLLocationManager()
    var index = Int()
    var appDelegate = AppDelegate()
    var arr_discover = [SalonListModel]()
    
    var marker_map = GMSMarker()
    var currentLocation = GMSMarker()
    var arrLocationData : NSMutableArray = NSMutableArray()
    
    var markerDict: [String: GMSMarker] = [:]
    var indicator = MaterialActivityIndicatorView()
    
    private var mapView: GMSMapView!
    private var clusterManager: GMUClusterManager!
    
    var arr_tapPin_Images :NSMutableArray = NSMutableArray()
    fileprivate var locationMarker : GMSMarker? = GMSMarker()

    @IBOutlet weak var btnLocation: UIButton!
    @IBOutlet weak var collection_View_usersalon: UICollectionView!
    @IBOutlet weak var view_map: GMSMapView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        setupActivityIndicatorView()
        
        MoveTab(Button: self.btnLocation)

        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        // Google Map
        let camera = GMSCameraPosition.camera(withLatitude: CLLocationDegrees(appDelegate.latitude),
                                              longitude: CLLocationDegrees(appDelegate.longitude), zoom: 10)
        mapView = GMSMapView.map(withFrame: self.view.frame, camera: camera)
        // Add the map to any view here
        view_map.addSubview(mapView)  //or customView.addSubview(mapView)
        
        let iconGenerator = GMUDefaultClusterIconGenerator()
        let algorithm = GMUNonHierarchicalDistanceBasedAlgorithm()
        let renderer = GMUDefaultClusterRenderer(mapView: mapView,
                                                 clusterIconGenerator: iconGenerator)
        clusterManager = GMUClusterManager(map: mapView, algorithm: algorithm,
                                           renderer: renderer)
        
        clusterManager.cluster()
        renderer.delegate = self
        
        viewConfigrations()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.indicator.startAnimating()
        SalonList()
    }
    
    override func viewWillLayoutSubviews()
    {
        super.viewWillLayoutSubviews()
        updateCellsLayout()
    }
    
    //MARK:Map Cluster Selection
    func clusterManager(_ clusterManager: GMUClusterManager, didTap cluster: GMUCluster) -> Bool
    {
        let newCamera = GMSCameraPosition.camera(withTarget: cluster.position,
                                                 zoom: mapView.camera.zoom + 1)
        let update = GMSCameraUpdate.setCamera(newCamera)
        
        self.mapView.delegate = self
        mapView.moveCamera(update)
        return false
    }
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool
    {
        if let poiItem = marker.userData as? POIItem
        {
            
            NSLog("Did tap marker for cluster item \(poiItem.location)")
            
            let poiItem = marker.userData as? POIItem
            marker.title = poiItem?.location
            // marker.snippet = poiItem?.address
            marker.icon = UIImage(named: "blue_pin")
            return false
            //            event_title = poiItem.name
            //            event_address = poiItem.eventAddress
            //            event_Date = poiItem.date
            //            event_distance = poiItem.distance
            //            map_image = poiItem.event_image
            // infoWindow = loadNiB()
            
        }
        else
        {
            NSLog("Did tap a normal marker")
        }
        return false
    }
    
    func renderer(_ renderer: GMUClusterRenderer, willRenderMarker marker: GMSMarker)
    {
        
        //marker.icon = UIImage(named: "gs_marker")
        
        if let userData = marker.userData {
            //  print(userData)
        }
        marker.map = nil
        guard let _ = marker.userData as? POIItem else { return }
        
        if let image = UIImage(named: "blue_pin")
        {
            marker.iconView = UIImageView(image: image, highlightedImage: nil)
        }
    }
    
    //MARK:Show Marker

    func showMarkerLocation(position: CLLocationCoordinate2D)
    {
        let marker3 = GMSMarker()
        // marker.map = nil
        //view_MapShow.clear()
        marker3.position = position
        marker3.title = addres
        marker3.snippet = country
        marker3.icon = UIImage(named: "blue_pin")!.withRenderingMode(.alwaysTemplate)
        marker3.map = mapView
    }
    
    //MARK:- Location Update
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let newLocation = locations.last
        view_map.camera = GMSCameraPosition.camera(withTarget: newLocation!.coordinate, zoom: 6.0)
        
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
        self.latitude = Float(locValue.latitude)
        self.longitude = Float(locValue.longitude)
        
        CLGeocoder().reverseGeocodeLocation(locationManager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks?[0]
                self.displayLocationInfo(pm)
            } else {
                print("Problem with the data received from geocoder")
            }
        })
    }
    
    func displayLocationInfo(_ placemark: CLPlacemark?)
    {
        if let containsPlacemark = placemark
        {
            //stop updating location to save battery life
            
            addres = appDelegate.address
            country = (containsPlacemark.country != nil) ? containsPlacemark.country! : ""
            
            let camera = GMSCameraPosition.camera(withLatitude: CLLocationDegrees(appDelegate.latitude), longitude: CLLocationDegrees(appDelegate.longitude), zoom: 16.0)
            view_map.camera = camera
            view_map.settings.zoomGestures = true
            view_map.animate(to: camera)
            view_map.isMyLocationEnabled = true
            view_map.delegate = self as? GMSMapViewDelegate
            
            print(latitude)
            
            showMarkerLocation(position: camera.target)
            locationManager.stopUpdatingLocation()
        }
    }
    
    func updateCellsLayout()
    {
        let centerX = collection_View_usersalon.contentOffset.x + (collection_View_usersalon.frame.size.width)/2
        
        for cell in collection_View_usersalon.visibleCells
        {
            var offsetX = centerX - cell.center.x
            if offsetX < 0 {
                offsetX *= -1
            }
            cell.transform = CGAffineTransform.identity
            let offsetPercentage = offsetX / (view.bounds.width * 2.7)
            let scaleX = 1-offsetPercentage
            cell.transform = CGAffineTransform(scaleX: scaleX, y: scaleX)
        }
    }
    
    //MARK:Api Call
    func SalonList()
    {
        arr_discover.removeAll()
        
        let defaults: UserDefaults? = UserDefaults.standard
        
        if(defaults?.dictionaryRepresentation().keys.contains("LoginStatus"))!
        {
            let param : [String: Any ] = ["latitude": appDelegate.latitude, "longitude":appDelegate.longitude,"distance_filter":"40"]
            
            print(param)
            
            NetworkHttpClient.callAPIWith(RequestPath.SalonlistApi.rawValue , parameter: param)
            { (success, jsonData, message, error) in
                
                if let json = jsonData
                {
                    self.indicator.stopAnimating()
                    
                    let swiftyJsonResponseDict = JSON(json)
                    print("swifty json print \(swiftyJsonResponseDict)")
                    
                    if success
                    {
                        if let arrEvent = json["saloninfo"].array
                        {
                            if arrEvent.count == 0
                            {
                                
                            }
                            else
                            {
                                for dict in arrEvent
                                {
                                    let salondata = SalonListModel(json: dict)
                                    self.arr_discover.append(salondata)
                                }
                                
                                self.collection_View_usersalon.reloadData()
                                
                                let arr = swiftyJsonResponseDict["saloninfo"].array! as NSArray
                                self.arrLocationData =  arr.mutableCopy() as! NSMutableArray
                                
                                if self.arrLocationData.count >= 1
                                {
                                    for i in 0...self.arrLocationData.count-1
                                    {
                                        var dic2 = JSON(self.arrLocationData.object(at: i))
                                        let items = POIItem(position: CLLocationCoordinate2DMake(CLLocationDegrees(dic2["latitude"].stringValue)!, CLLocationDegrees(dic2["longitude"].stringValue)!), location: dic2["location"].stringValue, salon_id: dic2["salon_id"].stringValue, salon_name: dic2["salon_name"].stringValue)
                                        
                                        self.clusterManager.add(items)
                                    }
                                    
                                }
                            }
                        }
                    }
                    else
                    {
                        let swiftyJsonResponseDict = JSON(json)
                        print("swifty json print \(swiftyJsonResponseDict)")
                        
                        print(json["message"].stringValue)
                        self.appDelegate.showAlert(title:Appttitle,message:swiftyJsonResponseDict["message"].stringValue,buttonTitle: alertok);
                    }
                }
            }
        }
        else
        {
            if(defaults?.dictionaryRepresentation().keys.contains("latitude"))!
            {
                let latitude = UserDefaults.standard.value(forKey: "latitude") as! String
                let longitude = UserDefaults.standard.value(forKey: "longitude") as! String
                
                let param : [String: Any ] = ["latitude": latitude, "longitude":longitude,"distance_filter":"40"]
                
                print(param)
                
                NetworkHttpClient.callAPIWith(RequestPath.SalonlistApi.rawValue , parameter: param)
                { (success, jsonData, message, error) in
                    
                    if let json = jsonData
                    {
                        self.indicator.stopAnimating()
                        
                        let swiftyJsonResponseDict = JSON(json)
                        print("swifty json print \(swiftyJsonResponseDict)")
                        
                        if success
                        {
                            if let arrEvent = json["saloninfo"].array
                            {
                                if arrEvent.count == 0
                                {
                                    
                                }
                                else
                                {
                                    for dict in arrEvent
                                    {
                                        let salondata = SalonListModel(json: dict)
                                        self.arr_discover.append(salondata)
                                    }
                                    
                                    self.collection_View_usersalon.reloadData()
                                    
                                    let arr = swiftyJsonResponseDict["saloninfo"].array! as NSArray
                                    self.arrLocationData =  arr.mutableCopy() as! NSMutableArray
                                    
                                    if self.arrLocationData.count >= 1
                                    {
                                        for i in 0...self.arrLocationData.count-1
                                        {
                                            var dic2 = JSON(self.arrLocationData.object(at: i))
                                            let items = POIItem(position: CLLocationCoordinate2DMake(CLLocationDegrees(dic2["latitude"].stringValue)!, CLLocationDegrees(dic2["longitude"].stringValue)!), location: dic2["location"].stringValue, salon_id: dic2["salon_id"].stringValue, salon_name: dic2["salon_name"].stringValue)
                                            
                                            self.clusterManager.add(items)
                                        }
                                        
                                    }
                                }
                            }
                        }
                        else
                        {
                            let swiftyJsonResponseDict = JSON(json)
                            print("swifty json print \(swiftyJsonResponseDict)")
                            
                            print(json["message"].stringValue)
                            self.appDelegate.showAlert(title:Appttitle,message:swiftyJsonResponseDict["message"].stringValue,buttonTitle: alertok);
                        }
                    }
                }
            }
        }
    }

    //MARK: - IBAction
    
    @IBAction func doclickonHome(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    @IBAction func doclickonBooking(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "MyBookingViewController") as! MyBookingViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    @IBAction func doclcikonProfile(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "MyProfileViewController") as! MyProfileViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func doclickonSearch(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    private func viewConfigrations()
    {
        collection_View_usersalon.register(UINib(nibName: "NearSalonsListCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "NearSalonsListCell")
        collection_View_usersalon.contentInset = UIEdgeInsets.init(top: 20, left: 30, bottom: 0, right: 30)
        //collection_View_usersalon.decelerationRate = UIScrollView.DecelerationRate.fast
    }
    
//    //MARK:- Location Update
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
//    {
//        let newLocation = locations.last
//        view_map.camera = GMSCameraPosition.camera(withTarget: newLocation!.coordinate, zoom: 6.0)
//
//        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
//
//        self.latitude = Float(locValue.latitude)
//        self.longitude = Float(locValue.longitude)
//
//        CLGeocoder().reverseGeocodeLocation(locationManager.location!, completionHandler: {(placemarks, error)->Void in
//
//            if (error != nil) {
//                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
//                return
//            }
//
//            if (placemarks?.count)! > 0 {
//                let pm = placemarks?[0]
//                self.displayLocationInfo(pm)
//            } else {
//                print("Problem with the data received from geocoder")
//            }
//        })
//    }
//
//    func displayLocationInfo(_ placemark: CLPlacemark?)
//    {
//        if let containsPlacemark = placemark
//        {
//            //stop updating location to save battery life
//
//            addres = appDelegate.address
//
//            //addres = (containsPlacemark.subLocality != nil) ? containsPlacemark.subLocality! : ""
//            country = (containsPlacemark.country != nil) ? containsPlacemark.country! : ""
//
//            let camera = GMSCameraPosition.camera(withLatitude: CLLocationDegrees(appDelegate.latitude), longitude: CLLocationDegrees(appDelegate.longitude), zoom: 16.0)
//            view_map.camera = camera
//            //    view_MapShow.settings.myLocationButton = true
//            //    view_MapShow.settings.compassButton = true
//            view_map.settings.zoomGestures = true
//            view_map.animate(to: camera)
//            view_map.isMyLocationEnabled = true
//            view_map.delegate = self as? GMSMapViewDelegate
//
//            print(latitude)
//
//
//            //  showMarker(position: camera.target)
//            locationManager.stopUpdatingLocation()
//            // RouteDraw()
//        }
//        //          viewMap.padding = UIEdgeInsets(top: 0, left: 0, bottom: 500, right: 10)
//    }
    
    @objc func clickOnBookNow(sender : UIButton)
    {
        index = sender.tag
        
        //let newBook = self.storyboard?.instantiateViewController(withIdentifier: "NewBookingViewController") as! NewBookingViewController
       // self.navigationController?.pushViewController(newBook, animated: true)
        
//        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SalonlistViewController") as! SalonlistViewController
//        self.navigationController?.pushViewController(secondViewController, animated: true)
        
        let salon = self.storyboard?.instantiateViewController(withIdentifier: "SalonProfileViewController") as! SalonProfileViewController
        let dic  = arr_discover[sender.tag]
        salon.salonlist = dic
        self.navigationController?.pushViewController(salon, animated: true)
    }
}

extension DiscoverSalonsViewController
{
    private func setupActivityIndicatorView()
    {
        view.addSubview(indicator)
        setupActivityIndicatorViewConstraints()
    }
    
    private func setupActivityIndicatorViewConstraints()
    {
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.widthAnchor.constraint(equalToConstant: 45.0).isActive = true
        indicator.heightAnchor.constraint(equalToConstant: 45.0).isActive = true
        indicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        indicator.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}

extension DiscoverSalonsViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arr_discover.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NearSalonsListCell", for: indexPath) as! NearSalonsListCollectionViewCell
       // cell.wallpaperImageView.image = UIImage(named: "\(indexPath.item)")
        
        //cell.lblSalon.text = "afafdfasf"
        
        let arr = arr_discover[indexPath.row]
        
        cell.lblUserName.text = arr.full_name!.firstUppercased
        cell.lblSalon.text = arr.salon_name!.firstUppercased
        
        if (arr.store_status! == "")
        {
            cell.btnStoreStaus.isHidden = true
        }
        else
        {
            if (arr.store_status! == "Open")
            {
                cell.btnStoreStaus.isHidden = false
                cell.btnStoreStaus.setTitle(arr.store_status!, for: .normal)
                cell.btnStoreStaus.backgroundColor = themecolor
            }
            else
            {
                cell.btnStoreStaus.isHidden = false
                cell.btnStoreStaus.setTitle(arr.store_status!, for: .normal)
                cell.btnStoreStaus.backgroundColor = UIColor.darkGray
            }
        }
        
        cell.img_user.kf.indicatorType = .activity
        (cell.img_user.kf.indicator?.view as? UIActivityIndicatorView)?.color =  UIColor.black
        cell.img_user.kf.setImage(with: URL(string:arr.profile_image!), placeholder: UIImage(named: ""))
 
        cell.btnBookNow.tag = indexPath.row
        cell.btnBookNow.addTarget(self, action: #selector(clickOnBookNow), for: .touchUpInside)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        var cellSize: CGSize = collection_View_usersalon.bounds.size
        
        cellSize.width -= collection_View_usersalon.contentInset.left * 2
        cellSize.width -= collection_View_usersalon.contentInset.right * 2
        cellSize.height = 165
        
        return cellSize
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        updateCellsLayout()
    }
}

//extension DiscoverSalonsViewController: GooglePlacesAutocompleteViewControllerDelegate
//{
//    func viewController(didAutocompleteWith place: PlaceDetails)
//    {
//        print(place.description)
//        placesSearchController.isActive = false
//    }
//}

