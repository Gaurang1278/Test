//
//  NearSalonsListCollectionViewCell.swift
//  Pavone
//
//  Created by CT on 4/1/19.
//  Copyright © 2019 CT. All rights reserved.
//

import UIKit

class NearSalonsListCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblSalon: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var img_user: UIImageView!
    @IBOutlet weak var btnBookNow: GradientBlueBtn!
    @IBOutlet weak var btnStoreStaus: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
