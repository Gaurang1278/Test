//
//  MyBookingViewController.swift
//  Pavone
//
//  Created by CTIMac on 30/03/19.
//  Copyright © 2019 CT. All rights reserved.
//

import UIKit
import MaterialActivityIndicator

class MyBookingViewController: UIViewController
{
    var index = Int()
    var arr_book = [MyBooking]()
    var booking_id:String = String()
    var refreshControl: UIRefreshControl!
    var boolLoader:Bool = Bool()
    var indicator = MaterialActivityIndicatorView()
    
    @IBOutlet weak var tableViewBookingList: UITableView!
    @IBOutlet weak var btnBook: GradientBlueBtn!
    @IBOutlet weak var btnBooking: UIButton!
    @IBOutlet weak var view_empty: UIView!

    enum TableSection: Int
    {
        case current = 0, older, drama, indie, total
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        MoveTab(Button: self.btnBooking)
        
        setupActivityIndicatorView()
        
       // ShowLoder()
        indicator.startAnimating()
        BookingList()
        
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = themecolor
        
        refreshControl.addTarget(self, action: #selector(BookingList), for: .valueChanged)
        
        if #available(iOS 10.0, *)
        {
            tableViewBookingList.refreshControl = refreshControl
        }
        else
        {
            // Fallback on earlier versions
        }
    }
    
    // MARK: - IBAction
    
    @IBAction func doclickonLocation(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "DiscoverSalonsViewController") as! DiscoverSalonsViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func doclickonSearch(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func doclickonHome(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func doclickonBooking(_ sender: Any)
    {
    }
    
    @IBAction func doclickonBookNow(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SalonlistViewController") as! SalonlistViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @IBAction func doclickonProfile(_ sender: Any)
    {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "MyProfileViewController") as! MyProfileViewController
        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
    @objc func clickOnMenuButton(sender : UIButton)
    {
        index = sender.tag
        let alert = UIAlertController(title: "Pavone", message: "Do you really want to delete this booking?", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default , handler:{
            (UIAlertAction)in
            
            self.booking_id = self.arr_book[sender.tag].booking_id!
            //ShowLoder()
            self.indicator.startAnimating()
            self.DeleteBooking()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel , handler:{
            (UIAlertAction)in
            
        }))
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    //MARK:Api Call
    func DeleteBooking()
    {
        // delete_booking
        let param : [String: Any ] = ["booking_id": self.booking_id]
        print(param)
        
        NetworkHttpClient.callAPIWith(RequestPath.DeleteBooking.rawValue , parameter: param) { (success, jsonData, message, error) in
            
            if let json = jsonData
            {
                
                self.indicator.stopAnimating()
                
                let swiftyJsonResponseDict = JSON(json)
                print("swifty json print \(swiftyJsonResponseDict)")
                
                if success
                {
                    self.BookingList()
                }
                else
                {
                    let swiftyJsonResponseDict = JSON(json)
                    print("swifty json print \(swiftyJsonResponseDict)")
                    
                    print(json["message"].stringValue)
                appDelegate.showAlert(title:Appttitle,message:swiftyJsonResponseDict["message"].stringValue,buttonTitle: alertok);

                }
            }
        }
    }
    
    @objc func BookingList()
    {
        arr_book.removeAll()
        
        let defaults: UserDefaults? = UserDefaults.standard
        
        if(defaults?.dictionaryRepresentation().keys.contains("client_id"))!
        {
            let client_id = UserDefaults.standard.value(forKey: "client_id") as! String
            let param : [String: Any ] = ["client_id": client_id]
            print(param)
            
            NetworkHttpClient.callAPIWith(RequestPath.MyBooking_list.rawValue , parameter: param) { (success, jsonData, message, error) in
                
                if let json = jsonData
                {
                    if(self.boolLoader == false)
                    {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1)
                        {
                            self.indicator.stopAnimating()
                        }
                        
                        self.boolLoader = true
                    }
                    
                    let swiftyJsonResponseDict = JSON(json)
                    
                    print("swifty json print \(swiftyJsonResponseDict)")
                    
                    if success
                    {
                        self.refreshControl.endRefreshing()
                        
                        if let arrbook = json["booking_detail"].array
                        {
                            if arrbook.count == 0
                            {
                                self.tableViewBookingList.isHidden = true
                                self.view_empty.isHidden = false
                            }
                            else
                            {
                                self.tableViewBookingList.isHidden = false
                                self.view_empty.isHidden = true

                                for dict in arrbook
                                {
                                    let NotiModel = MyBooking(json: dict)
                                    self.arr_book.append(NotiModel)
                                }
                                
                                if self.arr_book.count > 0
                                {
                                    self.tableViewBookingList.reloadData()
                                }
                            }
                        }
                    }
                    else
                    {
                        self.refreshControl.endRefreshing()
                        self.tableViewBookingList.isHidden = true
                        self.view_empty.isHidden = false
                    }
                }
            }
        }
    }
    
}

extension MyBookingViewController
{
    private func setupActivityIndicatorView()
    {
        view.addSubview(indicator)
        setupActivityIndicatorViewConstraints()
    }
    
    private func setupActivityIndicatorViewConstraints()
    {
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.widthAnchor.constraint(equalToConstant: 45.0).isActive = true
        indicator.heightAnchor.constraint(equalToConstant: 45.0).isActive = true
        indicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        indicator.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}

//MARK:Table View DataSource
extension MyBookingViewController : UITableViewDelegate , UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.arr_book.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableViewBookingList.dequeueReusableCell(withIdentifier: "MyBookingListCell", for: indexPath) as! MyBookingListTableViewCell
        
        cell.lblUserName.text = arr_book[indexPath.row].salon_name!.firstUppercased
        cell.lblPrice.text = arr_book[indexPath.row].service_cost! + " SAR"
        cell.lblAddress.text = arr_book[indexPath.row].barber_name!.firstUppercased
        cell.lblSalonName.text = arr_book[indexPath.row].service_name!.firstUppercased
        cell.lbl_date.text = arr_book[indexPath.row].book_dateTime!
        
        if (arr_book[indexPath.row].booking_status == "1")
        {
            cell.lbl_status.text = "Accepted"
            cell.lbl_status.textColor = UIColor.green
            cell.lbl_status.alpha = 0.8
            cell.btnMenuOption.isHidden = true
            cell.lbl_status.isHidden = false
        }
        else if (arr_book[indexPath.row].booking_status == "0")
        {
            cell.btnMenuOption.isHidden = false
            cell.lbl_status.isHidden = true
        }
        else
        {
            cell.lbl_status.text = "Rejected"
            cell.lbl_status.textColor = UIColor.red
            cell.lbl_status.alpha = 0.8
            cell.lbl_status.isHidden = false
        }
        
        cell.img_user.kf.indicatorType = .activity
        (cell.img_user.kf.indicator?.view as? UIActivityIndicatorView)?.color =  UIColor.black
        cell.img_user.kf.setImage(with: URL(string:arr_book[indexPath.row].salon_profile_image!), placeholder: UIImage(named: ""))

        cell.btnMenuOption.tag = indexPath.row
        cell.btnMenuOption.addTarget(self, action: #selector(clickOnMenuButton), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 175
    }
    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
//    {
//        return 50
//    }
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
//    {
//
//        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 50))
//        view.backgroundColor = UIColor(red: 245/255.0, green: 246/255.0, blue: 247/255.0, alpha: 1.0)
//        let label = UILabel(frame: CGRect(x: 20, y: 0, width: tableView.bounds.width - 30, height: 50))
//        label.font = UIFont.boldSystemFont(ofSize: 15)
//        //label.backgroundColor = UIColor(red: 180/255.0, green: 180/255.0, blue: 180/255.0, alpha: 0.1)
//        label.textColor =  UIColor(red: 112/255.0, green: 112/255.0, blue: 112/255.0, alpha: 0.7)
//        if let tableSection = TableSection(rawValue: section) {
//            switch tableSection {
//            case .current:
//                label.text = "Current Reservations"
//            case .older:
//                label.text = "Older Reservations"
//            default:
//                label.text = ""
//            }
//        }
//        view.addSubview(label)
//        return view
//    }
}
